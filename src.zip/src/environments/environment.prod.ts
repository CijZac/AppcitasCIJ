export const environment = {
  firebase: {
    projectId: 'cijcitas',
    appId: '1:757645963547:web:06034c1b8f024d608663be',
    databaseURL: 'https://cijcitas-default-rtdb.firebaseio.com',
    storageBucket: 'cijcitas.appspot.com',
    apiKey: 'AIzaSyAPdscxsWhSMh6zc3TnV4zynfc0LCr6pbQ',
    authDomain: 'cijcitas.firebaseapp.com',
    messagingSenderId: '757645963547',
  },
  production: true
};
