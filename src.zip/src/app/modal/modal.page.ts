import { Component, Input, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';
import { ModalController, ToastController } from '@ionic/angular';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.page.html',
  styleUrls: ['./modal.page.scss'],
})
export class ModalPage implements OnInit {
  @Input() id: string | undefined;
  Cita: any;

  constructor(private dataService: DataService, private modalCtrl: ModalController, private toastCtrl: ToastController) { }

  ngOnInit() {
    this.dataService.getCitaById(this.id).subscribe(res => {
      this.Cita = res;
    });
  }

  async deleteNote() {
    await this.dataService.deleteCita(this.Cita)
    this.modalCtrl.dismiss();
  }

  async updateNote() {
    await this.dataService.updateCitas(this.Cita);
    const toast = await this.toastCtrl.create({
      message: 'Cita Actualizada!.',
      duration: 2000
    });
    toast.present();
  }
}