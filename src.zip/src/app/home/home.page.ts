import { Component } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { NavController } from '@ionic/angular';
import { Router } from '@angular/router'; // Agregado para el enlace a la página de listado de citas

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  constructor(
    private navCtrl: NavController,
    private authService: AuthService,
    private router: Router // Agregado para el enlace a la página de listado de citas
  ) {}

  async logout() {
    try {
      await this.authService.logout();
      this.navCtrl.navigateRoot('/login'); // Redireccionar a la página de inicio de sesión
    } catch (error) {
      console.error('Error during logout:', error);
    }
  }

  gotoCitas() {
    this.router.navigateByUrl('/citas'); // Cambiar '/citas-list' por la ruta correcta de tu página de listado de citas
  }
  vertodas() {
    this.router.navigateByUrl('/director'); // Cambiar '/citas-list' por la ruta correcta de tu página de listado de citas
  }
  vercitas() {
    this.router.navigateByUrl('/administrador'); // Cambiar '/citas-list' por la ruta correcta de tu página de listado de citas
  }
}


